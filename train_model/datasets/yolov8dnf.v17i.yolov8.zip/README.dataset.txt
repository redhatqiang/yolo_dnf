# yolov8dnf > 2023-06-18 9:00pm
https://universe.roboflow.com/studydnf/yolov8dnf

Provided by a Roboflow user
License: CC BY 4.0

